(function () {
  const KIND = {
    choice: "Escolha",
    info: "Texto",
    task: "Tarefa",
    action: "Ligação",
    end: "Pode fechar",
  };

  const nav = [
    ["tese", "Tese"],
    ["campo", "O que fica e o que sai"],
    ["furos", "O que muda"],
    ["regras", "Regras"],
    ["ferramentas", "Ferramentas"],
    ["ordem", "Ordem de mudança"],
    ["patch", "Patch de nós"],
    ["mapa", "Mapa"],
    ["torto", "Fluxo · Bateu forte"],
    ["panico", "Fluxo · Pânico"],
    ["realidade", "Fluxo · Onde eu tô"],
    ["trava", "Fluxo · Paranoia"],
    ["falar", "Fluxo · Solidão"],
    ["samu", "Fluxo · Resgate"],
    ["cssrs", "Fluxo · C-SSRS"],
  ];

  const tools = [
    ["red_flag", "Antes de qualquer acalmar em droga, pânico e atalho.", "Dois botões. Dúvida liga o 192. Sem frase de 'você está seguro' antes."],
    ["cold_hand", "Pânico, pico, estimulante, dissociação.", "Gelo ou água fria na mão, 15–20 s. Rosto só se frio na cara não derruba a pessoa."],
    ["sigh", "Primeiro corpo no pânico.", "Duas puxadas pelo nariz, solta tudo pela boca. Três vezes."],
    ["breath_46", "Depois que o corpo baixou um grau.", "4 inspira, 1–2 segura, 6 solta. Até 10. Tontura: para. Um texto só, não nove cópias."],
    ["box", "Ainda alto, ou intenção ativa na triagem.", "4-4-4-4, quatro voltas. Não é ferramenta de overdose."],
    ["hum", "Pânico, nervo vago.", "Boca fechada, hmm, 15 segundos, sentir o peito."],
    ["anchor_3", "Depois do corpo. Não no primeiro segundo.", "Três coisas que vê e os pés no chão. O 5-4-3-2-1 inteiro fica para depois."],
    ["one_change", "Onda, paranoia, overamp mental.", "Muda uma coisa: luz, som ou cômodo. Não reforma o ambiente."],
    ["reality_script", "Paranoia e estimulante.", "A pessoa diz: estou sob efeito. Isto passa. Som alto piora. O app não discute o medo."],
    ["cool_down", "Estimulante e MDMA.", "Parar de se mexer. Pano frio na nuca, axila ou atrás do joelho. Vento e sombra. Goles ou isotônico se acordado. Não litros."],
    ["no_mix", "Álcool, G, benzo, opioide.", "Não soma outro depressor. Não sugere benzo para descer."],
    ["recovery", "Não acorda mas respira.", "De lado, joelho de cima dobrado. Não dá água. Não deixa só. Não sacode."],
    ["naloxone_if", "Não acorda, respiração ruim, pode ser opioide.", "Se tiver e alguém souber: uma dose, 192, espera 2–3 min, pode repetir, fica até o fim. Não reverte estimulante. No Brasil nem sempre existe na esquina."],
    ["urge_surf", "Quero mais uma agora.", "A vontade é onda. Dez minutos sem alimentar. HALT antes: fome, raiva, solidão, cansaço."],
    ["crt_10", "Mensagem, redose, decisão grande.", "Dez segundos. Dois pensamentos."],
    ["butterfly", "Trava, se o toque próprio for ok.", "Braços cruzados, toque alternado nos ombros. Devagar."],
    ["micro_move", "Freeze.", "Dedo do pé, um lado e outro. Caminhada de 20 min não é ferramenta de pico."],
    ["lighthouse", "Qualquer pico, e resgate se a pessoa está acordada.", "Estou aqui. Isto passa. Não vou a lugar nenhum. Uma frase. Pergunta de sim ou não."],
    ["safety_micro", "Depois da triagem, se o risco subiu.", "Quatro linhas: sinal, o que eu faço só, uma pessoa, 188 e 192. Sem descrever método."],
    ["comedown_bridge", "Tristeza súbita depois de estimulante ou festa.", "A queda mente que isso é a vida inteira. O peso é real. O para sempre não é."],
  ];

  function beat(id, k, t, go, risk) {
    return { id, k, t, go: go || [], risk: !!risk };
  }
  function go(label, to) {
    return [label, to];
  }

  const flows = {
    mapa: {
      title: "Mapa",
      lede: "O atalho não pula o portão. Dúvida no corpo é ligação. Ideação não fica presa só em Solidão.",
      beats: [
        beat("home", "choice", "Home. Seis portas. O botão preciso de algo agora entra no portão, não na técnica.", [
          go("Bateu forte", "torto"),
          go("Pânico", "panico"),
          go("Onde eu tô", "realidade"),
          go("Paranoia", "trava"),
          go("Solidão", "falar"),
          go("Resgate", "samu"),
        ]),
        beat("rf", "choice", "Bandeira vermelha, compartilhada. Dor no peito que espalha, convulsão, não acorda, respiração lenta ou lábio roxo, muito calor com confusão, um lado do corpo fraco.", [
          go("Sim ou não sei", "samu"),
          go("Não, nenhuma", "torto"),
        ], true),
      ],
    },
    torto: {
      title: "Bateu forte",
      lede: "Portão primeiro. Esfriar de verdade. Não misturar. Sem número mágico de copo. Até poder parar: 5 a 7 telas.",
      beats: [
        beat("a1", "choice", "Tô aqui. O que tá mais perto do agora?", [
          go("Acelerou, calor, coração", "red_flag"),
          go("Onda, tudo estranho", "red_flag"),
          go("Álcool, G ou derrubou", "no_mix"),
          go("Usei seringa", "red_flag"),
          go("Não usei nada", "panico"),
          go("Estão me olhando", "trava"),
        ]),
        beat("red_flag", "choice", "Alguma destas agora? Dor ou aperto no peito. Convulsão, desmaio, não acorda. Respiração muito lenta ou lábio roxo. Muito calor e confusão. Um lado fraco, boca torta, fala embolada.", [
          go("Sim ou não sei", "samu"),
          go("Não · estimulante", "cool"),
          go("Não · onda", "psych"),
          go("Não · seringa e estável", "inject"),
        ], true),
        beat("cool", "task", "Para de se mexer sem parar. Pano frio na nuca, axila ou atrás do joelho. Se acordado: goles ou isotônico, não litros. Afasta o resto. Não soma outra coisa.", [go("Esfriei", "one")]),
        beat("one", "task", "Uma coisa só no ambiente: luz baixa ou som baixo.", [go("Uma coisa", "reality")]),
        beat("reality", "task", "Diz em voz alta, se der: estou sob efeito. Isto passa. Som alto piora.", [go("Disse", "check")]),
        beat("psych", "info", "A percepção mudou. O chão não. Não luta com a onda. Eu fico.", [go("Continuar", "one")]),
        beat("no_mix", "choice", "Álcool, G ou outro depressor. Você está acordado e conseguindo ler?", [
          go("Acordado", "alcool"),
          go("Apagando, vômito, respiração ruim", "recovery"),
        ], true),
        beat("alcool", "task", "Alguns goles e comida se o estômago aceitar. Não dirige. Não soma benzo, G nem opioide. Sem 250 ml por dose.", [go("Feito", "check")]),
        beat("recovery", "action", "De lado. Joelho de cima dobrado. Não dá água. Não deixa só. SAMU 192. Bombeiros 193.", [go("Continuar", "nalox")], true),
        beat("nalox", "info", "Se a respiração está ruim e pode ser opioide: quem souber usa naloxona, avisa o 192, espera 2–3 minutos, fica. Não reverte estimulante.", [go("192", "samu")]),
        beat("inject", "info", "Se está estável: não compartilha seringa. Se a respiração já está lenta, esquece a aula e fica na tela do 192.", [go("Estável", "check")]),
        beat("check", "choice", "E agora, comparado com quando abriu?", [
          go("Um pouco melhor", "breath"),
          go("Quero mais uma", "urge"),
          go("Piorou no corpo", "samu"),
          go("Caiu uma tristeza enorme", "comedown"),
        ]),
        beat("urge", "task", "A vontade é onda. Dez minutos sem alimentar. Onde está no corpo. HALT: uma coisa pequena. Não pega mais uma.", [go("Esperei", "breath")]),
        beat("breath", "task", "4 inspira, segura pouco, 6 solta. Para se der tontura.", [go("Respirei", "gente")]),
        beat("gente", "choice", "Tem alguém, ou prefere o 188?", [
          go("Tem alguém", "fecha"),
          go("188", "cvv"),
        ]),
        beat("cvv", "action", "CVV 188. Voz humana, 24 horas.", [go("Continuar", "fecha")]),
        beat("comedown", "info", "A queda mente que isso é a vida inteira. O peso é real. O para sempre não é.", [go("Ir para Solidão", "falar")]),
        beat("fecha", "end", "Você ficou. O próximo minuto basta. 188 continua aqui."),
      ],
    },
    panico: {
      title: "Pânico",
      lede: "Portão, uma ferramenta de corpo, uma âncora curta, pode parar. A fila de nove técnicas acaba.",
      beats: [
        beat("red", "choice", "Dor no peito que espalha, desmaio, convulsão, falta de ar de verdade, um lado fraco? Na dúvida conta como sim.", [
          go("Sim ou não sei", "samu"),
          go("Não, nenhuma", "corpo"),
        ], true),
        beat("corpo", "choice", "Sem esses sinais, um aviso para o corpo. Qual cabe agora?", [
          go("Gelo na mão", "gelo"),
          go("Suspiro", "sigh"),
          go("Usei algo", "torto"),
        ]),
        beat("gelo", "task", "Gelo ou água fria na mão, 15 segundos. Rosto só se frio na cara não te derruba.", [go("Senti o frio", "frame")]),
        beat("sigh", "task", "Duas puxadas pelo nariz, solta tudo pela boca. Três vezes.", [go("Três vezes", "frame")]),
        beat("frame", "info", "Sem aqueles sinais, o pico costuma ser alarme falso. Não é garantia. Se mudar, o 192 está em cima.", [go("Continuar", "anchor")]),
        beat("anchor", "task", "Três coisas que você vê. Os dois pés no chão.", [go("Ancorei", "check")]),
        beat("check", "choice", "E agora?", [
          go("Baixou um pouco", "cvv"),
          go("Ainda alto", "ainda"),
        ]),
        beat("ainda", "choice", "Mais uma ferramenta, não as quatro.", [
          go("Humming", "hum"),
          go("Box", "box"),
        ]),
        beat("hum", "task", "Boca fechada, hmmmm, 15 segundos, sente o peito.", [go("Vibrou", "cvv")]),
        beat("box", "task", "4-4-4-4, quatro voltas.", [go("Fiz", "cvv")]),
        beat("cvv", "action", "Se quiser voz humana agora: CVV 188.", [go("Continuar", "fecha")]),
        beat("fecha", "end", "Não é fraqueza. É fisiologia. Pode parar aqui. 188 fica."),
      ],
    },
    realidade: {
      title: "Onde eu tô",
      lede: "Sem diagnóstico na entrada. Toque, nomear, frio na mão, uma respiração. O nome clínico, se existir, fica no fim e é opcional.",
      beats: [
        beat("a1", "choice", "Parece filme, ou você parece longe de você. O que está mais forte?", [
          go("Tudo longe ou eu longe", "plain"),
          go("Usei algo", "torto"),
          go("Coração disparado junto", "panico"),
        ]),
        beat("plain", "info", "É o nervo se protegendo. Incômodo, e em geral passa. Você está aqui. O chão está aqui.", [go("Continuar", "toque")]),
        beat("toque", "task", "Toca o tecido da roupa. Palma na parede ou no chão.", [go("Senti", "nomeia")]),
        beat("nomeia", "task", "Diz três objetos que existem neste cômodo.", [go("Nomeei", "frio")]),
        beat("frio", "task", "Gelo ou água fria na mão.", [go("Frio", "breath")]),
        beat("breath", "task", "4, segura pouco, 6. Uma série só.", [go("Respirei", "check")]),
        beat("check", "choice", "O estranho diminuiu um pouco?", [
          go("Um pouco", "move"),
          go("Ainda forte", "move"),
        ]),
        beat("move", "task", "Aperta e solta os punhos, devagar. Mexe os dedos dos pés.", [go("Me movi", "gente")]),
        beat("gente", "choice", "Alguém pode ficar perto, mesmo em silêncio?", [
          go("Posso chamar", "fecha"),
          go("Não agora", "cvv"),
        ]),
        beat("cvv", "action", "CVV 188.", [go("Continuar", "fecha")]),
        beat("fecha", "end", "Você ficou, mesmo com tudo estranho. Pode ir devagar. 188 aqui."),
      ],
    },
    trava: {
      title: "Paranoia",
      lede: "A sensação é real. Não se discute. Baixa uma coisa do ambiente. SMS só depois de dez segundos.",
      beats: [
        beat("a1", "choice", "Tô aqui. O que trava mais agora?", [
          go("Estão me olhando ou julgando", "frame"),
          go("Travei, não mexo", "frame"),
          go("Falta de ar junto", "panico"),
          go("Tudo irreal junto", "realidade"),
          go("Pensamento de acabar", "cssrs"),
        ]),
        beat("frame", "info", "A sensação está real. Discutir com ela não ajuda. Vamos baixar uma coisa só.", [go("Continuar", "uma")]),
        beat("uma", "task", "Capuz, olhar no chão, ou som mais baixo. Uma. Costa numa parede, se der.", [go("Baixei uma", "script")]),
        beat("script", "task", "Em voz alta: eu estou aqui. O excesso de som ou luz piora. Isto passa.", [go("Disse", "corpo")]),
        beat("corpo", "choice", "O corpo deixa fazer algo pequeno?", [
          go("Quase nada", "pes"),
          go("Consigo os braços", "hug"),
        ]),
        beat("pes", "task", "Dedos dos pés, um lado e outro.", [go("Mexi", "check")]),
        beat("hug", "task", "Braços cruzados, toque alternado nos ombros, devagar. Só se tocar em você for ok.", [go("Toquei", "check")]),
        beat("check", "choice", "A agitação cedeu um pouco?", [
          go("Um pouco", "gente"),
          go("Ainda alto", "cvv"),
        ]),
        beat("gente", "choice", "Tem alguém para um SMS curto?", [
          go("Sim", "crt"),
          go("Não", "cvv"),
        ]),
        beat("crt", "task", "Dez segundos antes de enviar.", [go("Pausei", "sms")]),
        beat("sms", "action", "Mensagem pronta: tô mal, pode ficar na linha?", [go("Continuar", "fecha")]),
        beat("cvv", "action", "CVV 188. Não é tarefa riscada. É ligação.", [go("Continuar", "fecha")]),
        beat("fecha", "end", "Você não saiu. O corpo sai da trava no tempo dele. 188 aqui."),
      ],
    },
    falar: {
      title: "Solidão, depressão, pico",
      lede: "Três portas num fluxo só. Pensamento de acabar não passa por diário. CVV não é checkbox.",
      beats: [
        beat("a1", "choice", "Tô aqui. O que pesa mais neste minuto?", [
          go("Muito só ou vazio", "so"),
          go("Pico: choro, raiva, vergonha", "pico"),
          go("Pensamento de acabar ou de me machucar", "cssrs"),
          go("Usei algo", "torto"),
          go("Não sei se o corpo está seguro", "samu"),
        ]),
        beat("so", "info", "A dor é real. Não é drama. E não é o resto da vida inteira, mesmo o cérebro jurando que é.", [go("Continuar", "halt")]),
        beat("halt", "task", "Antes de decidir qualquer coisa grande: fome, raiva ou cansaço? Uma coisa pequena. Água, comida, banho.", [go("Uma coisa", "gente")]),
        beat("pico", "choice", "Uma coisa para o corpo.", [
          go("Gelo", "gelo"),
          go("Punho", "punho"),
        ]),
        beat("gelo", "task", "Gelo na mão, 15 segundos.", [go("Frio", "crt")]),
        beat("punho", "task", "Aperta o punho 5 segundos e solta. Três vezes.", [go("Soltei", "crt")]),
        beat("crt", "task", "Não manda a mensagem ainda. Dez segundos.", [go("Pausei", "palavra")]),
        beat("palavra", "choice", "Qual a palavra desse pico? Uma.", [
          go("Qualquer palavra", "gente"),
        ]),
        beat("gente", "choice", "Alguém na linha, ou 188?", [
          go("Tem alguém", "wa"),
          go("Ninguém", "cvv"),
        ]),
        beat("wa", "action", "Texto pronto, você aperta enviar: ei, tô passando mal. Pode ficar na linha?", [go("Continuar", "plano")]),
        beat("cvv", "action", "CVV 188. Voz humana, 24 horas.", [go("Continuar", "plano")]),
        beat("plano", "task", "Uma coisa só para a próxima hora. Água, cortina, banho, cama.", [go("Tenho uma", "fecha")]),
        beat("fecha", "end", "Você não está só. Não precisa estar bem. Pode parar aqui."),
      ],
    },
    samu: {
      title: "Resgate",
      lede: "Ligar é o beat zero. O que você vê vem em seguida, para guiar quem espera. Sem promessa sobre polícia.",
      beats: [
        beat("liga", "action", "Liga agora. Fala: socorro médico, o que você vê, o lugar, fica na linha. Embalagem se tiver. Não precisa narrar crime. SAMU 192. Bombeiros 193.", [go("Liguei", "vendo")], true),
        beat("vendo", "choice", "Enquanto eles vêm, ou ainda na linha. O que você vê?", [
          go("Não acorda ou respiração ruim", "lado"),
          go("Muito quente, agitado ou dor no peito", "calor"),
          go("Convulsionando", "conv"),
          go("Caiu", "queda"),
          go("Boca torta ou um lado fraco", "avc"),
          go("Acordado, pânico ou medo", "luz"),
        ]),
        beat("lado", "action", "De lado. Joelho de cima dobrado. Não dá água. Não sacode. Não deixa só. Se puder ser opioide e tiver naloxona: uma dose, avisa o SAMU, espera 2–3 minutos.", [go("De lado", "prep")], true),
        beat("calor", "info", "Para de se mexer. Pano frio na nuca, axila, atrás do joelho. Não segura à força. Não discute o que a pessoa está vendo. Dor no peito: diz isso para o SAMU.", [go("Continuar", "prep")]),
        beat("conv", "info", "Nada na boca. Não segura o corpo. Afasta o que machuca. Quando passar, de lado. Continua na linha.", [go("Continuar", "prep")]),
        beat("queda", "info", "Não move. Se suspeitar de coluna, as mãos só impedem a cabeça de girar. O SAMU guia.", [go("Continuar", "prep")]),
        beat("avc", "info", "Boca torta, um braço fraco, fala embolada: diz essas três coisas para o atendente. Agora.", [go("Avisar", "prep")]),
        beat("luz", "info", "Se está acordado: estou aqui. Isto passa. Não vou a lugar nenhum. Licença antes de tocar. Uma mudança só: luz ou som.", [go("Continuar", "prep")]),
        beat("prep", "task", "Lugar claro para a equipe. Nome e idade, e o que pode ter usado, se souber. Alguém na porta.", [go("Pronto", "cuida")]),
        beat("cuida", "info", "Você também passou por isso. Três respirações lentas. 188 é seu também, depois.", [go("Continuar", "depois")]),
        beat("depois", "action", "CVV 188 para quem cuidou. CAPS é acolhimento do SUS, não hospital. Sem lista inventada.", [go("Continuar", "fecha")]),
        beat("fecha", "end", "Você ficou com a pessoa. Isso importa. Cuida de você também."),
      ],
    },
    cssrs: {
      title: "C-SSRS",
      lede: "Pergunta direta, sem lista de métodos na tela. Se a ideia ativa é não, a pergunta do ato ainda é feita.",
      beats: [
        beat("c1", "choice", "Nos últimos 30 dias, você desejou estar morto ou dormir e não acordar?", [
          go("Sim", "pausa"),
          go("Não", "c2"),
        ], true),
        beat("pausa", "task", "Três respirações 4-6. Só três. O texto antigo dizia três no título e dez no corpo.", [go("Três", "c2")]),
        beat("c2", "choice", "Você teve pensamentos de acabar com a própria vida?", [
          go("Sim", "c3"),
          go("Não", "c6"),
        ], true),
        beat("c3", "choice", "Você pensou em como seria? Sem exemplos na tela.", [
          go("Sim", "gelo"),
          go("Não", "c4"),
        ]),
        beat("gelo", "task", "Água fria ou gelo na mão, 15 segundos.", [go("Feito", "c4")]),
        beat("c4", "choice", "Teve esses pensamentos e alguma intenção de agir?", [
          go("Sim", "box"),
          go("Não", "c5"),
        ], true),
        beat("box", "task", "Box 4 por 4, quatro ciclos.", [go("Respirei", "c5")]),
        beat("c5", "choice", "Você começou a organizar um plano? Sim não pede detalhes. Vai para afastar, na hora.", [
          go("Sim", "meios"),
          go("Não", "c6"),
        ], true),
        beat("c6", "choice", "Nos últimos 3 meses, você fez, começou ou preparou alguma coisa para acabar com a própria vida?", [
          go("Sim, nestes 3 meses", "emerg"),
          go("Sim, mas faz mais tempo", "passado"),
          go("Não", "coping"),
        ], true),
        beat("emerg", "action", "Isso pede gente agora. Pode ligar junto com alguém. CVV 188. SAMU 192.", [go("Continuar", "meios")], true),
        beat("passado", "action", "Faz tempo, e ainda importa. Uma voz agora: CVV 188.", [go("Continuar", "safety")]),
        beat("meios", "task", "Mais longe, por agora. Não precisa jogar fora. Remédio noutro cômodo ou com alguém. Objeto que corta, ou arma, com outra pessoa. Sai de janela e varanda. Senta no chão.", [go("Mais longe", "safety")], true),
        beat("coping", "choice", "Continuo aqui. O que ajuda mais neste minuto?", [
          go("Um plano curto", "safety"),
          go("Uma foto ou razão", "hope"),
          go("O que disparou", "gatilho"),
        ]),
        beat("safety", "task", "Quatro linhas: um sinal de que o pico voltou. Uma coisa que você faz sem ninguém. Uma pessoa. 188 e 192 já estão nesta tela.", [go("Anotei", "gatilho")]),
        beat("hope", "task", "Uma foto que acalma, ou uma razão pequena para as próximas horas, ou uma mensagem antiga boa.", [go("Olhei", "gatilho")]),
        beat("gatilho", "choice", "Uma palavra, se quiser. O que disparou?", [
          go("Substância ou álcool", "torto"),
          go("Outra coisa ou não sei", "falar"),
        ]),
      ],
    },
  };

  const pages = {
    tese: `
      <h2>Tese</h2>
      <p class="lede">O app já sabe acolher. Ainda não sabe, cedo o bastante, quando tem que parar de acolher e ligar.</p>
      <p>Motivação é a maior categoria dos 191 nós. Redução de danos específica é quase nada. O caminho curto até um fim calmo tem 16 a 22 telas. Quem está no pico não lê isso.</p>
      <p>O produto real é o atalho, mais um portão de bandeira vermelha, mais uma técnica, mais uma voz humana. O resto é companhia, e companhia é opt-in: fica mais um pouco, ou fecha com o 188 na tela.</p>
      <p class="note">Isto não é atendimento. Não entra em produção sem revisão clínica. Endereço de CAPS e qualquer frase sobre polícia continuam pendentes de checagem local.</p>
      <div class="files">
        <span>index.html</span>
        <span>style.css</span>
        <span>app.js</span>
        <a href="../sos-002-harm-control.zip">Baixar o zip</a>
      </div>
    `,
    campo: `
      <h2>O que fica e o que sai</h2>
      <p>O que circula entre quem passa por isso mistura ouro com veneno. O app separa.</p>
      <h3>Fica</h3>
      <ul>
        <li><strong>Gelo na mão</strong> até doer, e o suspiro duplo, no primeiro minuto. Hoje estão no fim de uma fila de técnicas.</li>
        <li><strong>Dizer o óbvio em voz alta.</strong> Estou sob efeito. O som alto piora. Isto passa. Não “ninguém está te olhando”.</li>
        <li><strong>Frase curta.</strong> Dois botões, não pergunta aberta. Sentar sem guiar. Atravessar sem baixar a pessoa na marra.</li>
        <li><strong>A queda depois do estimulante</strong> mente que a vida inteira é aquilo. O peso é real. O para sempre não é.</li>
        <li><strong>Posição de lado, ficar, não dar água</strong> se a pessoa não acorda. Naloxona só se existir e alguém souber usar.</li>
      </ul>
      <h3>Não entra</h3>
      <ul>
        <li>Benzo, álcool ou mais uma dose para “descer” ou “limpar”.</li>
        <li>Spray, suplemento ou truque viral sem protocolo.</li>
        <li>Tutorial de quanto usar, via ou tempo de redose.</li>
        <li>Lista de métodos na pergunta da triagem. A pergunta fica. Os exemplos não.</li>
        <li>“Você não está morrendo” antes de perguntar dor no peito, calor, convulsão, respiração.</li>
        <li>A garantia de que o resgate não chama a polícia.</li>
      </ul>
    `,
    furos: `
      <h2>O que muda de verdade</h2>
      <table>
        <thead><tr><th></th><th>Hoje</th><th>Ajuste</th></tr></thead>
        <tbody>
          <tr><td>1</td><td>Acalmar antes de checar o corpo</td><td>Um portão, dois botões, dúvida liga</td></tr>
          <tr><td>2</td><td>Bateu forte sem 192 cedo</td><td>Barra 188/192 o tempo todo. Atalho começa no portão</td></tr>
          <tr><td>3</td><td>250 ml por dose, água à vontade</td><td>Corta o número. Acordado: goles. Apagando: nada pela boca</td></tr>
          <tr><td>4</td><td>Calor só como ventilador</td><td>Parar, pano frio, sombra. Confuso e muito quente é 192. Não há antídoto de estimulante</td></tr>
          <tr><td>5</td><td>Injeção sem falar de respiração lenta</td><td>Respiração ruim primeiro. Aula de seringa só se estável. Naloxona se houver e se opioide for possível</td></tr>
          <tr><td>6</td><td>G ausente</td><td>G com álcool apaga fácil. Lado, nada pela boca, 192. Sem mililitro</td></tr>
          <tr><td>7</td><td>Triagem pula o ato se a ideia for não. Texto diz “se machucar”</td><td>O ato é perguntado mesmo assim. Texto: acabar com a própria vida. Sem exemplos</td></tr>
          <tr><td>8</td><td>Plano de segurança só afasta meios</td><td>Quatro linhas depois: sinal, o que eu faço só, uma pessoa, 188/192</td></tr>
          <tr><td>9</td><td>Nove técnicas seguidas, respiração tarde, caminhada no pico</td><td>Portão, um corpo, uma âncora, check, humano, pode parar</td></tr>
          <tr><td>10</td><td>Várias morais no fim. Dois nós iguais em Paranoia</td><td>Uma frase. O resto é “fica mais”</td></tr>
          <tr><td>11</td><td>Obrigado, sozinho, nome de diagnóstico na cara</td><td>Valeu por contar. Você não está só. Experiência primeiro</td></tr>
          <tr><td>12</td><td>CVV como caixinha</td><td>Hotline é botão, nunca checklist</td></tr>
        </tbody>
      </table>
      <h3>O que dizer no 192</h3>
      <p>Preciso de socorro médico agora. A pessoa não acorda, ou respira devagar, ou está muito quente e confusa, ou tem dor no peito, ou está em convulsão. Estamos neste lugar. Vou ficar na linha.</p>
      <p class="note">Não precisa narrar crime, quantidade nem o que era. Se tiver embalagem, guarda para a equipe. Não prometemos o que a viatura faz.</p>
    `,
    regras: `
      <h2>Regras do fluxo</h2>
      <ol>
        <li>Ligar é o primeiro pixel quando o caso é corpo. Texto depois da ligação.</li>
        <li>Uma bandeira vermelha, dois botões, em Bateu forte, Pânico e em todo preciso de algo agora.</li>
        <li>No pico, no máximo seis telas até poder fechar.</li>
        <li>Uma técnica por tela. Se não mexeu, a pessoa escolhe a próxima.</li>
        <li>Não discutir a realidade dela. Baixar uma coisa do ambiente.</li>
        <li>Não oferecer substância para consertar substância.</li>
        <li>Frase de farol: estou aqui. Isto sobe e desce. O próximo minuto basta.</li>
        <li>Toque só com permissão. Vale para o amigo no resgate também.</li>
        <li>188 no meio, não só no slide de tchau.</li>
        <li>Número, endereço e promessa legal ficam escondidos até alguém verificar no chão.</li>
      </ol>
      <h3>Voz</h3>
      <p>Você, nunca tu. Sem Obrigado. Sem sempre, de verdade, na hora, não está morrendo. Rótulos iguais aos da home: Bateu forte, Pânico, Onde eu tô, Paranoia, Solidão, Resgate. Travei, Onde estou e Tô sozinho saem dos botões. No pico, cerca de 25 palavras.</p>
      <h3>Imagem, se um dia existir</h3>
      <ul>
        <li>Três quadros da posição de lado.</li>
        <li>Onde por o pano frio: nuca, axila, atrás do joelho.</li>
        <li>Quinze segundos sem fala do suspiro duplo.</li>
        <li>O orb que já existe para o 4-6.</li>
      </ul>
      <p class="note">Sem autoplay com som. Sem imagem de uso. Sem imagem de método.</p>
    `,
    ferramentas: `<h2>Ferramentas</h2><p>Um componente, muitos fluxos. O parágrafo da respiração hoje está colado em nove nós.</p><div class="tools" id="tools"></div>`,
    ordem: `
      <h2>Ordem, só de conteúdo</h2>
      <ol>
        <li>Criar o portão e colocar na frente de Bateu forte, Pânico e dos atalhos. Enquanto não existe, apagar as frases absolutas de segurança.</li>
        <li>Corrigir a triagem: não na ideia ainda pergunta o ato. Acabar com a própria vida. Três ciclos querem dizer três. Sem lista de métodos.</li>
        <li>Trocar a frase da polícia. Trocar 250 ml por dose. Trocar água ilimitada pelo cartão de esfriar.</li>
        <li>Barra 188/192 dentro de Bateu forte.</li>
        <li>Ligar ou apagar órfãos. Cortar o nó duplicado. CVV deixa de ser checkbox.</li>
        <li>Encurtar cada caminho até poder parar. A cauda motivacional vira um nó.</li>
        <li>Entrar queda química, onda da fissura, não misturar, naloxona se houver, microplano, script de realidade.</li>
        <li>Lista de CAPS continua escondida. CAPS não é hospital.</li>
        <li>Alguém da clínica assina portão, naloxona no Brasil, G, calor, triagem e a frase do SAMU.</li>
      </ol>
      <p>Nada disso depende de redesign. É frase e caminho.</p>
    `,
    patch: `
      <h2>Patch de nós</h2>
      <p>O que não está aqui fica, até a poda da cauda. Revisão clínica antes de publicar.</p>
      <h3>Bateu forte</h3>
      <ul>
        <li><strong>a3_stim</strong> deixa de ser órfão e entra no esfriar, depois do portão. Cortar “não está colapsando” e “baixa de verdade”.</li>
        <li><strong>fast_stim</strong> vira parar, pano frio, goles, afastar, não somar. Dor no peito abre o 192, não uma caixinha.</li>
        <li><strong>m3</strong> sai do caminho principal. Segunda água fria seguida é repetição.</li>
        <li><strong>m9 e álcool</strong> perdem o 250 ml. Apagando: de lado, sem água, 192.</li>
        <li><strong>m12 a m15</strong> viram um fecho.</li>
      </ul>
      <h3>Pânico</h3>
      <ul>
        <li><strong>a3_severe e m1</strong> perdem “não está morrendo” e “não está em perigo real”. A frase que fica é condicional, depois do portão: costuma ser alarme falso. Não é garantia.</li>
        <li>A fila breath, suspiro, mindfulness, humming, rabisco, água de novo e box deixa de ser obrigatória.</li>
      </ul>
      <h3>Onde eu tô, Paranoia, Solidão</h3>
      <ul>
        <li><strong>realidade.a2</strong> descreve a experiência. O nome clínico sai da entrada. O redirect para Pânico, hoje órfão, ganha um botão.</li>
        <li><strong>trava.a3_paranoia</strong> para de afirmar que ninguém olha. m11 e m14 são o mesmo texto: fica um.</li>
        <li><strong>falar</strong> separa só, pico e pensamento de acabar. Caminhada sai do pico. CVV sai do checklist. Obrigado sai.</li>
      </ul>
      <h3>Resgate e triagem</h3>
      <ul>
        <li><strong>instant_rescue</strong> troca a frase da polícia pelo roteiro da ligação. A triagem do que se vê volta depois do telefonema, não antes.</li>
        <li><strong>m10</strong>, hoje morto, entra no cuidado de quem ficou com a pessoa.</li>
        <li><strong>c2 = não</strong> vai para c6, não para o menu de coping. c6 deixa de dizer “se machucar”. Plano sim vai para meios na hora, sem pedir o plano.</li>
      </ul>
      <h3>Não mexer</h3>
      <p>torto.m1, torto.a2_unclear, falar.m2, falar.m9, panico.m10 depois do portão, trava.a3_freeze, realidade.a3_anchor, samu.m11. Posição de lado, não mover quem caiu, pausa antes do SMS, uma pergunta da triagem por vez.</p>
    `,
  };

  const main = document.getElementById("conteudo");
  const navEl = document.getElementById("nav");

  nav.forEach(function (item) {
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = item[1];
    b.dataset.id = item[0];
    b.addEventListener("click", function () {
      show(item[0]);
    });
    navEl.appendChild(b);
  });

  function esc(s) {
    return String(s)
      .replace(/&/g, "&")
      .replace(/</g, "<")
      .replace(/>/g, ">");
  }

  function show(id) {
    Array.prototype.forEach.call(navEl.children, function (btn) {
      btn.setAttribute("aria-current", btn.dataset.id === id ? "true" : "false");
    });
    if (pages[id]) {
      main.innerHTML = pages[id];
      if (id === "ferramentas") paintTools();
    } else if (flows[id]) {
      paintFlow(id);
    }
    main.focus();
    window.scrollTo(0, 0);
  }

  function paintTools() {
    const box = document.getElementById("tools");
    tools.forEach(function (row) {
      const el = document.createElement("article");
      el.className = "tool";
      el.innerHTML = "<b>" + esc(row[0]) + "</b><span>" + esc(row[1]) + "</span><p>" + esc(row[2]) + "</p>";
      box.appendChild(el);
    });
  }

  function paintFlow(id) {
    const flow = flows[id];
    main.innerHTML = "";
    const head = document.createElement("div");
    head.className = "flow-head";
    head.innerHTML = "<h2>" + esc(flow.title) + "</h2><p class=\"lede\">" + esc(flow.lede) + "</p>";
    main.appendChild(head);
    flow.beats.forEach(function (node) {
      const card = document.createElement("article");
      card.className = "beat" + (node.risk ? " risk" : "");
      card.id = "n-" + node.id;
      const outs = document.createElement("div");
      outs.className = "outs";
      (node.go || []).forEach(function (edge) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.innerHTML = esc(edge[0]) + " <span class=\"arrow\">→</span>";
        btn.addEventListener("click", function () {
          const target = edge[1];
          if (flows[target]) {
            show(target);
            return;
          }
          const local = document.getElementById("n-" + target);
          if (local) local.scrollIntoView({ block: "start" });
        });
        outs.appendChild(btn);
      });
      card.innerHTML = "<div class=\"kind\">" + esc(KIND[node.k] || node.k) + " · " + esc(node.id) + "</div><p>" + esc(node.t) + "</p>";
      card.appendChild(outs);
      main.appendChild(card);
    });
  }

  show("tese");
})();
